Pour utiliser: 
	- Ouvrir son terminal
	- Se déplacer en utilisant le terminal dans le répertoir de l'application
	- Executer la commande: 
		$ node server.js
	- Ouvrir son navigateur et se rendre a l'adresse:
		http://localhost:7777/


Limites du programme:
	- Le programme ne vérifie pas les entités entrées
	- Le programme ne valide pas que le champ aliment n'est pas vide